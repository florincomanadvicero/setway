<?php defined( 'LS_ROOT_FILE' ) || exit; ?>
<script type="text/html" id="tmpl-slider-group-item">
	<div class="slider-item group-item" data-id="">
		<div class="slider-item-wrapper">
			<div class="items">

			</div>
		</div>
		<div class="info">
			<div class="name">
				<?php _e('Unnamed Group', 'LayerSlider') ?>
			</div>
		</div>
	</div>
	<div class="ls-hidden">
		<div></div>
	</div>
</script>